// declare module 'react-native-vector-icons/Ionicons';
declare module 'react-native-material-menu';
declare module 'react-native-video';